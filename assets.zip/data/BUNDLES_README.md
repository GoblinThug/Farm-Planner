# bundles.json

Справочник наборов Stardew Valley для будущей вкладки «Узелки».

- `standardBundles`: 30 стандартных наборов Центра сообщества + отдельный `missing-bundle` (Пропавший набор).
- `remixedBundles`: альтернативные варианты, которые могут появляться при включённой опции Remixed Bundles. Это пул вариантов, а не наборы, которые обязательно появятся все одновременно.
- `rooms`: комнаты и награды за полное восстановление каждой комнаты.
- `colorPalette`: палитра и индексы цветов из Stardew Valley Wiki.

Важно по цветам:
- Для стандартных наборов заполнены цветовые индексы по опубликованным Wiki raw bundle data.
- Wiki описывает цвета и их индексы, но не указывает конкретный цвет каждого ремикс-варианта в таблице вариантов. Поэтому цвет remixed-записей намеренно оставлен `null`, чтобы не выдавать предположение за подтверждённый факт.

Основные источники:
- https://stardewvalleywiki.com/Bundles
- https://stardewvalleywiki.com/Remixed_Bundles
- https://stardewvalleywiki.com/Modding:Bundles
- https://stardewvalleywiki.com/Community_Center

Данные предназначены для игры 1.6.x. Wiki-описания способов получения сохранены в виде кратких русских подсказок. Для UI следует показывать поля `methods`, `seasons`, `locations`, `time`, `weather`, `notes`, `minimumQuality`, `quantity`.
